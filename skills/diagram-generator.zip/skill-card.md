## Description: <br>
Generate and edit diagrams with the mcp-diagram-generator MCP server for Draw.io, Mermaid, and Excalidraw outputs across network topology, architecture, flowchart, swimlane, UML, mind map, and whiteboard work. <br>

This skill is ready for commercial/non-commercial use. <br>

## Publisher: <br>
[matthewyin](https://clawhub.ai/user/matthewyin) <br>

### License/Terms of Use: <br>
MIT-0 <br>


## Use Case: <br>
Developers and technical teams use this skill to turn diagram requests into structured diagram specifications and saved diagram files. It supports creating or editing Draw.io, Mermaid, and Excalidraw diagrams for documentation, architecture reviews, network topology planning, workflows, UML-style models, and whiteboard collaboration. <br>

### Deployment Geography for Use: <br>
Global <br>

## Known Risks and Mitigations: <br>
Risk: The skill can direct an agent to create configuration, output directories, and diagram files, including custom output paths requested by the user. <br>
Mitigation: Review requested output paths before generation and confirm that file writes are limited to the intended workspace location. <br>
Risk: Diagram quality depends on the selected format, valid schema fields, unique element IDs, edge endpoints, and layout geometry. <br>
Mitigation: Use the relevant playbook and quality gate before generation, then inspect the saved file enough to confirm the expected format-specific properties exist. <br>
Risk: The skill relies on the mcp-diagram-generator MCP server to write files. <br>
Mitigation: Review the MCP server package or source before first use, as recommended by the server-resolved security guidance. <br>


## Reference(s): <br>
- [ClawHub skill page](https://clawhub.ai/matthewyin/skills/diagram-generator) <br>
- [Interaction Intake Guide](references/interaction-intake-guide.md) <br>
- [Format Selection Guide](references/format-selection-guide.md) <br>
- [JSON Schema Guide](references/json-schema-guide.md) <br>
- [Layout Quality Guide](references/layout-quality-guide.md) <br>
- [Network Topology Examples](references/network-topology-examples.md) <br>
- [Architecture Playbook](references/playbook-architecture.md) <br>
- [Excalidraw Playbook](references/playbook-excalidraw.md) <br>
- [Flowchart Playbook](references/playbook-flowchart.md) <br>
- [Network Topology Playbook](references/playbook-network-topology.md) <br>
- [Swimlane Playbook](references/playbook-swimlane.md) <br>
- [UML Playbook](references/playbook-uml.md) <br>


## Skill Output: <br>
**Output Type(s):** [Markdown, Code, Configuration instructions, API Calls, Files, Guidance] <br>
**Output Format:** [Markdown responses with structured JSON diagram specifications and MCP tool calls that produce .drawio, .mmd, or .excalidraw files] <br>
**Output Parameters:** [1D] <br>
**Other Properties Related to Output:** [May initialize .diagram-config.json and write diagram files under default or user-requested output paths through the configured MCP server.] <br>

## Skill Version(s): <br>
1.1.6 (source: server release evidence) <br>

## Ethical Considerations: <br>
Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment. <br>
